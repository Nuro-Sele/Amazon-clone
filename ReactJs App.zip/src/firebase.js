import firebase from "firebase"

const firebaseApp = firebase.initializeApp({ 
    apiKey: "AIzaSyBK-jWl1xnVGqdUiSnTMFkvr8hH1AXOIjg",
    authDomain: "web-shop-aa620.firebaseapp.com",
    projectId: "web-shop-aa620",
    storageBucket: "web-shop-aa620.appspot.com",
    messagingSenderId: "612788246890",
    appId: "1:612788246890:web:d65228c6b5fb07ba81ad13"
});

const db = firebaseApp.firestore();
const auth = firebase.auth();

export {db,auth};
