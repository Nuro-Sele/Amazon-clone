import Product from "./Product"
import "./Home.css"

function Home(){
    return(
        <div className="home">
            <img className="home__image"
            src="https://images.unsplash.com/photo-1496715976403-7e36dc43f17b?q=80&w=1770&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" 
            alt=""/>

            <div className="home__row">
                <Product
                    id="1"
                    title="The Lean Startup: How Contact Innavation"
                    price={50.96}
                    rating={5}
                    image="https://m.media-amazon.com/images/I/71W1KvLH3sL._AC_SX569_.jpg"
                />
                <Product
                    id="2"
                    title="The Lean Starddddtup: How Contact Innavation"
                    price={35.96}
                    rating={2}
                    image="https://m.media-amazon.com/images/I/51rBkRj5MjL._AC_SY355_.jpg"
                />
                <Product
                    id="3"
                    title="The Lean Startup: How Contggggact Innavation"
                    price={23.96}
                    rating={4}
                    image="https://m.media-amazon.com/images/I/51rBkRj5MjL._AC_SY355_.jpg"
                />
            </div>
            <div className="home__row">
                <Product
                    id="4"
                    title="The Lean Startup: How Contact Innavation"
                    price={50.96}
                    rating={5}
                    image="https://m.media-amazon.com/images/I/71W1KvLH3sL._AC_SX569_.jpg"
                />
                <Product
                    id="5"
                    title="The Lean Starddddtup: How Contact Innavation"
                    price={35.96}
                    rating={2}
                    image="https://m.media-amazon.com/images/I/51rBkRj5MjL._AC_SY355_.jpg"
                />
                <Product
                    id="6"
                    title="The Lean Startup: How Contggggact Innavation"
                    price={23.96}
                    rating={4}
                    image="https://m.media-amazon.com/images/I/51rBkRj5MjL._AC_SY355_.jpg"
                />
                <Product
                    id="7"
                    title="The Lean Startup: How Contggggact Innavation"
                    price={23.96}
                    rating={4}
                    image="https://m.media-amazon.com/images/I/51rBkRj5MjL._AC_SY355_.jpg"
                />
            </div>
            <div className="home__row">
            <Product
                    id="8"
                    title="The Lean Startup: How Contggggact Innavation"
                    price={23.96}
                    rating={4}
                    image="https://m.media-amazon.com/images/I/51rBkRj5MjL._AC_SY355_.jpg"
                />
                <Product
                    id="9"
                    title="The Lean Startup: How Contggggact Innavation"
                    price={23.96}
                    rating={4}
                    image="https://m.media-amazon.com/images/I/51rBkRj5MjL._AC_SY355_.jpg"
                />
            </div>
        </div>
    )
}

export default Home