import React from 'react'
import "./Footer.css"

function Footer(){

        return (
            <div className='footerarea'>
                <h1>The Footer stays here!</h1>
                <div className="footerarea__top">
                    <p>Back to the Top</p>
                </div>
            </div>
        )    
}

export default Footer