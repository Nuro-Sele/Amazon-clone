import React from "react"
import CurrencyFormat from "react-currency-format"



function Subtotal(){
    return(
    <div className="subtotal">

        <button>Proceed to Checkout</button>
    </div>
    )
}

export default Subtotal