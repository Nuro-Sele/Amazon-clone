import React from "react";
import "./Checkout.css"
import Subtotal from "./Subtotal"


function Checkout(){
    return(
        <div>
            <div className="checkout_left">
                <div>
                    <h2 className="checkout_title">Your shopping cart is empty.</h2>
                    <p>You have no items products in your cart. Buy some!</p>
                </div>
            </div>
            <div className="checkout_right">
                <Subtotal/>
            </div>
        </div>
    )
}

export default Checkout